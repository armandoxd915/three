# Three
git clone https://github.com/WilliamXixi/Three
cd Three
cd Will
php will.php
Done 
