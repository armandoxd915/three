# Three
Ini Script Boleh Gw Record Ya Deck
> Tata Cara Pakai Di Termux

> Ketik Di termux 
> 1.pkg update && pkg upgrade

> 2.pkg install git

> 3.pkg install php

> 4.git clone https://github.com/WilliamXixi/Three

> 5.cd Three

> 6.php will.php

Done Itu Aja Sih");

<div align="center">

<img src="https://i.ibb.co/Np8P4nN/9b2b698ce8baa0d04f1ed9c401bea43b.jpg" alt="Bot-Will" width="300" />

# Kang Copas

>

>

>

</div>

<p align="center">

  <a href="https://github.com/WilliamXixi"><img title="Author" src="https://img.shields.io/badge/Author-YansWill-red.svg?style=for-the-badge&logo=github" /></a>

  <h4 align="center">

  <a href="https://wa.me/6285710223047">YansWill >//< </a>

</h4>

</p>
